COSMOS FOR KIDS — VS CODE PROJECT

Files:
- index.html: page structure
- style.css: original styling extracted from the original single-file website
- script.js: original inline JavaScript preserved in order and isolated in separate blocks

HOW TO RUN
1. Open this folder in Visual Studio Code.
2. Install the Live Server extension (optional but recommended).
3. Right-click index.html and choose Open with Live Server.
4. Keep internet on because some images and external libraries may load from online sources.

Keep a backup before editing. This split preserves the original content and features as closely as possible.

PLANET GRAPHICS QUALITY UPDATE
- Planet close-up uses 2048x1024 procedural fallback maps and denser cloud layers.
- When online, the simulator attempts to load 2K planetary surface maps from Solar System Scope's public texture download CDN.
- If the CDN is unavailable, procedural maps remain active automatically.
- Three.js is loaded from CDN by the existing project, so keep internet on for 3D mode.
- High-resolution maps may increase bandwidth/GPU use; the renderer caps pixel ratio at 2 for performance.


LATEST UPDATE
- Removed the Planet mode button from the unified simulation bar; Solar System and Galaxy remain. Clicking a planet in the Solar System still opens the separate close-up planet explorer.
- Increased close-up sphere tessellation, renderer pixel-ratio cap, and improved hemisphere/key/rim lighting.
- Fixed cloud texture canvas clearing dimensions.
- The close-up viewer still attempts to load 2K surface maps online and uses procedural fallbacks if unavailable.
